package cn.inlee.mapper;

import cn.inlee.beans.SysRolePermission;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author CF
 * @since 2020-09-13
 */
public interface SysRolePermissionMapper extends BaseMapper<SysRolePermission> {

}
