package cn.inlee.mapper;

import cn.inlee.beans.SysUser;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.toolkit.Constants;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author CF
 * @since 2020-09-13
 */
public interface SysUserMapper extends BaseMapper<SysUser> {

	SysUser selectByUserName(@Param(Constants.WRAPPER) Wrapper<SysUser> queryWrapper);

}
