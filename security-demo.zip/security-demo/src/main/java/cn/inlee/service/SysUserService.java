package cn.inlee.service;

import cn.inlee.beans.SysUser;

import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.springframework.security.core.userdetails.UserDetailsService;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.toolkit.Constants;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author CF
 * @since 2020-09-13
 */
public interface SysUserService extends IService<SysUser>,UserDetailsService{
	
	public SysUser selectByUserName(String userName);

}
