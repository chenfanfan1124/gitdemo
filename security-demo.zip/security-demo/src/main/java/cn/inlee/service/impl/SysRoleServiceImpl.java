package cn.inlee.service.impl;

import cn.inlee.beans.SysRole;
import cn.inlee.mapper.SysRoleMapper;
import cn.inlee.service.SysRoleService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author CF
 * @since 2020-09-13
 */
@Service
public class SysRoleServiceImpl extends ServiceImpl<SysRoleMapper, SysRole> implements SysRoleService {

}
