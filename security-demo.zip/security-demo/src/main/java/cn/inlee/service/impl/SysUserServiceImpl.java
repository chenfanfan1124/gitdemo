package cn.inlee.service.impl;

import cn.inlee.beans.SysRole;
import cn.inlee.beans.SysUser;
import cn.inlee.mapper.SysUserMapper;
import cn.inlee.service.SysRoleService;
import cn.inlee.service.SysUserService;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Constants;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author CF
 * @since 2020-09-13
 */
@Service
public class SysUserServiceImpl extends ServiceImpl<SysUserMapper, SysUser> implements SysUserService {


	@Autowired
	SysRoleService 	sysRoleService;
	
	@Autowired
	SysUserMapper sysUserMapper;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

		SysUser sysUser = selectByUserName(username);
		
		System.out.println(sysUser);
		return sysUser;
	}
	
	@Override
	public SysUser selectByUserName(String userName) {
		
		QueryWrapper<SysUser> wrapper = new QueryWrapper<>();
		wrapper.eq("username", userName);
		return sysUserMapper.selectByUserName(wrapper);
		
	
	}

}
