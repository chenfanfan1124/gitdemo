package cn.inlee.service;

import cn.inlee.beans.SysPermission;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author CF
 * @since 2020-09-13
 */
public interface SysPermissionService extends IService<SysPermission> {

}
