package cn.inlee.service.impl;

import cn.inlee.beans.SysRolePermission;
import cn.inlee.mapper.SysRolePermissionMapper;
import cn.inlee.service.SysRolePermissionService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author CF
 * @since 2020-09-13
 */
@Service
public class SysRolePermissionServiceImpl extends ServiceImpl<SysRolePermissionMapper, SysRolePermission> implements SysRolePermissionService {

}
