package cn.inlee.utils;

import java.io.ByteArrayOutputStream;
import java.security.KeyFactory;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

import javax.crypto.Cipher;


public class RsaUtils {
	//优选商城
	private static final String publicKey = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC8yaIDU2BWsO2hub8QXan3RRoiG2R6CItfbXBMtwV0QrNBOAo+izxdKzuwt2lEbLNQ3GqltMOalVvDcImOwl8tSlLv9a+5X5lKmDuDsyyqWU8wp9Lr6eIfmpifAhcJvsRWlTWaOhPSBYV/YBRyQREcFAnOqds0YfM6MVUl23WUywIDAQAB";
	private static final String privatekey = "MIICdQIBADANBgkqhkiG9w0BAQEFAASCAl8wggJbAgEAAoGBALADNERXclUsJzsv33qex406pB3ABpcFuHtPNOyt+/ovaZzrnCR2obV4uPCwpQfJHVi0FK9Xdz9LhOTjzc2lzzrttvVKzxK4f8yRT4qOMdDGBW/5Kkqki3c79A8lV4FOcKdU17hqBqCIjEI9DXnF6IzXwNhr1oRZKMT0SkI/c5JJAgMBAAECgYA5e2Jna1OYg0nwp2rJpe8vrVYJrTu5uJGOG8kB/rQK+c75A21D70ZSeLGVUWskBsdBv9X9iYgVMLme8tK0dZEediQGazVrE+dsESQAKdEUVYhhk4NJ7SwJjTFXZjDVzqwGQy8WNFeGcCjUeCHbNFNklq4GQ3mytbWjKkSyR2JqsQJBAPnPvCky2biFrtKS8EeC7kbKRLok8g2kJoxOX9J7+Pgyt8C6iAKpouoJ62fFZskgTnt/DWiF5v0fz5CREA90tL0CQQC0X3KmDkE8tWzDpuDAjN20jnCPo6TSr04u/BJXiA6j5PWOeern07SmNXJeH21HRI3+1bDTEJ8Wxuln4zJCHrp9AkB84IyF58aQiDs5RnzYsqncN1ad2sQpb4pZjwA1nwV5RRk4Pcap1hT7e5Py3uof1oeFEqEoQ++RT2qaMPnfUA7dAkAf52IYDR1s54o9cR7/7+qnLSqrvX5B5dAmb1+vK9mrE6x7bwUlzER/waRhEZ36pR2YnaORMbdyB+zw+zbAiz7hAkBr1ZJRuXKdq3g8n3m/Upn14PYK3ficni8souvOCJ0ShYRU0QN5zRMs55ZBKbyPhOjPggBu2tjNgpYhouxbZo+0";

					    //X509			优选商城测试
//	private static final String publicKey = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCj4Vx11cAaz2KgcPjsSYqPgQYmcc7kUK+AFfCg6ubatAWfmPwb5nl0sH2ufwkrQZMrxf6byLkLAZ1Tx3Y1+WHBv5MXvx3EGZcZDm3umSSRUr5Yf1arZCwg";
						//PKCS8
//	private static final String privatekey = "MIICdQIBADANBgkqhkiG9w0BAQEFAASCAl8wggJbAgEAAoGBAIhpVxL73Ok2eEmOyxavVtF8wZ67MOiS+rK5KY8TNP08w6tEy09HM44jbCNjspo/7AJ51lNmo8BQLybgvn46j/jcBTaDOeTQXIPVZi0rIm9kK6b4k7l67jY07hC1poPv9DQ+XQMev4pl8o694hS5H6bwFzBC3utSZFPJ97F9EAdpAgMBAAECgYAlke27esbTLH9gswVYUB53QAcLsr67r4+AneLGVyHnBU9W4nGkehXG9haYgKL2PNjBrdDL058SHoN+D7Qni/WOylbRFSuqEqF9VkjnY9L63j8N2CDkfQkARZhbXamMqYYvFqXyg/7ywGf+h23awt8UnTF2QhLNq+JczAAWktMHqQJBAOAUa2sseD9eUcwLnMpCJoLL8nTPNeEEoUqWmlNQgnWmUUXvl94x3j3wfhfSeVfWqAIQ73rv5gTYsxBhlw48Mn8CQQCb1+WAp4RcaMQCZph7DWeVPdXT3J26HVvdFgJeS4jERRWl5aT6IQzAH1p+Hd9G74mwz24WaAg+QX+sf0oEfYIXAkAmyyI1scM3pUqf+rqwQXeNWWWmV2FKjZSm5x/coKmVWK/lXa97JkMFkiciVKvxSxZXFTuAmxvFZwbJJTwTmNRdAkBOGLEP+eKglHe1ZEiBUcRYy7X+B46bF99TOZZSPrP4903T5vL3zdwf4xZsIPglCiEME8btP5Dx8czTWq5y9ZpdAkByn7PHzWLBrkzgLZj0/2qyjZAMsI+jDLT6zuAsue0wd6mUoPq/SU8DJaSUrwzSWEAvbp6wLvigr/oMPxmPfHnA";	

	
	public static void main(String[] args) throws Exception {
		String pubEncoderMsg = pubEncoderMsg("274390010");
		System.out.println(priDecodeMsg(pubEncoderMsg));
		
		String priEncoderMsg = priEncoderMsg("529508042");
		System.out.println(pubDecodeMsg(priEncoderMsg));
	}
	
	/**
	 * 公钥加密
	 */
	public static String pubEncoderMsg(String msg) throws Exception {
		
		byte[] pukByte = Base64.getDecoder().decode(publicKey);
		X509EncodedKeySpec xencode = new X509EncodedKeySpec(pukByte);
		 PublicKey puk = KeyFactory.getInstance("RSA").generatePublic(xencode);
		 
		 Cipher cipher = Cipher.getInstance("RSA");
		 cipher.init(Cipher.ENCRYPT_MODE, puk);
		 
		 byte[] doFinal = doFinal(cipher,msg.getBytes(),msg.getBytes().length,true); 
		 
		 byte[] encode = Base64.getEncoder().encode(doFinal);
		 return new String(encode);
	}
	
	/**
	 * 私钥加密
	 */
	public static String priEncoderMsg(String msg) throws Exception {
		
		byte[] priByte = Base64.getDecoder().decode(privatekey);
		
		PKCS8EncodedKeySpec xencode = new PKCS8EncodedKeySpec(priByte);
		 PrivateKey puk = KeyFactory.getInstance("RSA").generatePrivate(xencode);
		 
		 Cipher cipher = Cipher.getInstance("RSA");
		 cipher.init(Cipher.ENCRYPT_MODE, puk);
		 
		 byte[] doFinal = doFinal(cipher,msg.getBytes(),msg.getBytes().length,true); 
		 
		 byte[] encode = Base64.getEncoder().encode(doFinal);
		 return new String(encode);
	}
	
	/**
	 * 公钥解密
	 */
	public static String pubDecodeMsg(String Msg) throws Exception {
		
		byte[] puk = Base64.getDecoder().decode(publicKey);
		X509EncodedKeySpec xencode = new X509EncodedKeySpec(puk);
		
		PublicKey generatePublic = KeyFactory.getInstance("RSA").generatePublic(xencode);
		
		Cipher cipher = Cipher.getInstance("RSA");
        cipher.init(Cipher.DECRYPT_MODE, generatePublic);
      
        byte[] decode = Base64.getDecoder().decode(Msg.getBytes());
       
        byte[] doFinal = doFinal(cipher,decode,decode.length,false); 
	
        return new String(doFinal);
	}
	
	/**
	 * 私钥解密
	 */
	public static String priDecodeMsg(String Msg) throws Exception {
		
		byte[] prk = Base64.getDecoder().decode(privatekey);
		PKCS8EncodedKeySpec xencode = new PKCS8EncodedKeySpec(prk);
		
		PrivateKey generatePrivate = KeyFactory.getInstance("RSA").generatePrivate(xencode);
		
		Cipher cipher = Cipher.getInstance("RSA");
        cipher.init(Cipher.DECRYPT_MODE, generatePrivate);
      
        byte[] decode = Base64.getDecoder().decode(Msg.getBytes());
       
       
        byte[] doFinal = doFinal(cipher,decode,decode.length,false); 
	
        return new String(doFinal);
	}
	
	private static byte[] doFinal(Cipher cipher, byte[] data, int inputLen, boolean isEncryptMode) throws Exception {
	       int maxBlockSize = isEncryptMode ? 117 : 128;
	       ByteArrayOutputStream out = new ByteArrayOutputStream();
	       int offSet = 0;
	       byte[] cache;
	       int i = 0;
	       while (inputLen - offSet > 0) {
	           if (inputLen - offSet > maxBlockSize) {
	               cache = cipher.doFinal(data, offSet, maxBlockSize);
	           } else {
	               cache = cipher.doFinal(data, offSet, inputLen - offSet);
	           }
	           out.write(cache, 0, cache.length);
	           i++;
	           offSet = i * maxBlockSize;
	       }
	       byte[] result = out.toByteArray();
	       out.close();
	       return result;
	   }
	
	 /**
     * encode By SHA-256
     * @param str
     * @return
     */
    public static String encodeBySHA256(String str) {

        if (str == null) {

            return null;}

         try { 

            MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
            messageDigest.reset();
            messageDigest.update(str.getBytes());
            return getFormattedText(messageDigest.digest());

        } catch (Exception e) {

    throw new RuntimeException(e);}

    }

    private static final char[] HEX_DIGITS = { '0', '1', '2', '3', '4', '5','6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };

    /**
     * Takes the raw bytes from the digest and formats them correct.
     * @param bytes the raw bytes from the digest.
     * @return the formatted bytes.
     */
    private static String getFormattedText(byte[] bytes) {

        int len = bytes.length;

        StringBuilder buf = new StringBuilder(len * 2);

        // 把密文转换成十六进制的字符串形式

        for (int j = 0; j < len; j++) {

            buf.append(HEX_DIGITS[(bytes[j] >> 4) & 0x0f]);

            buf.append(HEX_DIGITS[bytes[j] & 0x0f]);

        }

         return buf.toString();

    }
}
