package cn.inlee.utils;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 	常用参数
 * @author heyucong
 *
 */
public class SybConstants {

	private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	/**生产环境**/
	
	//微信JSAPI统一下单 地址
	public static final String SYB_JSAPI_URL ="https://api.mch.weixin.qq.com/pay/unifiedorder";

	public static final String SYB_JSAPI_APPID = "wx9ff634e60afa8d6a";
	public static final String SYB_MCH_ID = "1493723182";
	public static final String SYB_JSAPI_KEY = "X6mG58JSv0pL5OZFM5pcYlOw6OuDFxZG";
	public static final String SYS_NOTIFYURL = "http://trade.inlee.com.cn/gateway/wxpay/notify";
	
	//京东通知地址
	public static final String JD_NOTIFYURL = "https://cvop.jd.com/component/http/JSON/youli/v1/order/confirm";
	
	public static String getDate(Date date) {
		return sdf.format(date);
	}
	
	
}
