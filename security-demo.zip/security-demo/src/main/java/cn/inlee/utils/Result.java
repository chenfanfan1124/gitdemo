package cn.inlee.utils;

import lombok.Data;

@Data
public class Result<T> {

	private String code; //状态码
	private String msg;	//描述信息
	private T Data; //返回数据
	
	public static <T> Result<T> ok(T data) {
		Result<T> result = new Result<>();
		result.setCode("0000");
		result.setMsg("success");
		result.setData(data);
		return result;
	}
	
	public static <T> Result<T> error(T data) {
		Result<T> result = new Result<>();
		result.setCode("5000");
		result.setMsg("error");
		result.setData(data);
		return result;
	}
	
	public static Result<?> ok() {
		Result<?> result = new Result<>();
		result.setCode("0000");
		result.setMsg("success");
		return result;
	}
	
	public static Result<?> error() {
		Result<?> result = new Result<>();
		result.setCode("5000");
		result.setMsg("error");
		return result;
	}
	
	public static  Result<?> error(String msg) {
		Result<?> result = new Result<>();
		result.setCode("5000");
		result.setMsg(msg);
		return result;
	}
}
