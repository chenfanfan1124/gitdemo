package cn.inlee.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.metadata.IPage;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class QueryBillController {
	
	
	
	
	@GetMapping("/test1")
	public String test1() {
		// 获取security上下文中，用户信息
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		System.out.println(JSONObject.toJSONString(authentication));
		return "test1";
	}
	
	@PreAuthorize("hasRole('ERP')")
	@GetMapping("/test2")
	public String test2() {
		
		return "test2";
	}
	
	@GetMapping("/test3")
	public String test3() {
		
		return "test3";
	}
	
	@Secured("ROLE_ADMIN")
	@GetMapping("test4")
	public String test4() {
		
		return "Success2";
	}
}
