package cn.inlee.beans;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.extension.activerecord.Model;

import lombok.Data;

import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;

import org.springframework.security.core.GrantedAuthority;

/**
 * <p>
 * 
 * </p>
 *
 * @author CF
 * @since 2020-09-13
 */
@Data
public class SysRole extends Model<SysRole> implements GrantedAuthority{

    private static final long serialVersionUID = 1L;

    /**
     * 编号
     */
    @TableId(value = "ID", type = IdType.AUTO)
    private Integer id;

    /**
     * 角色名称
     */
    private String roleName;

    /**
     * 角色描述
     */
    private String roleDesc;


  
    @Override
    protected Serializable pkVal() {
        return this.id;
    }

	@Override
	public String getAuthority() {
		// TODO Auto-generated method stub
		return roleName;
	}
}
