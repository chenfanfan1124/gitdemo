package cn.inlee.config;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.authentication.configurers.provisioning.InMemoryUserDetailsManagerConfigurer;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.annotation.web.configurers.ExpressionUrlAuthorizationConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.session.SessionInformationExpiredStrategy;

import cn.inlee.service.SysUserService;

@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(securedEnabled = true,prePostEnabled = true)
public class SecurityConfig extends WebSecurityConfigurerAdapter{
	
	@Autowired
	SysUserService sysUserService;
	
	@Bean
	public BCryptPasswordEncoder passwordEncoder() {
		
	   return new BCryptPasswordEncoder();
	}

	@Override
	public void configure(AuthenticationManagerBuilder auth) throws Exception {
		
		
		InMemoryUserDetailsManagerConfigurer<AuthenticationManagerBuilder> inMemoryAuthentication = auth.inMemoryAuthentication();
		
		// ERP角色
		List<SimpleGrantedAuthority> user2 = Arrays.asList("ROLE_ERP").stream().map(SimpleGrantedAuthority::new).collect(Collectors.toList());
		
		//ERP角色和 ADMIN角色		read,write,play 权限
		List<SimpleGrantedAuthority> user3 = Arrays.asList("ROLE_ERP","ROLE_ADMIN","read","write","play").stream().map(SimpleGrantedAuthority::new).collect(Collectors.toList());
		
				
		inMemoryAuthentication.withUser("user").password(passwordEncoder().encode("123")).authorities(new ArrayList<SimpleGrantedAuthority>());
		inMemoryAuthentication.withUser("user2").password(passwordEncoder().encode("123")).authorities("ADMIN","ERP").authorities(user2);
		inMemoryAuthentication.withUser("user3").password(passwordEncoder().encode("123")).authorities(user3);	

		
	
	}

	@Override
	public void configure(HttpSecurity http) throws Exception {
		
		http.authorizeRequests()
							//	.antMatchers("/test2").hasRole("ADMIN")		// 访问 /test 要有 ERP角色
								.antMatchers("/test3").hasAnyAuthority("read","write")	// 访问 /test2  要有read或write权限
								.anyRequest().authenticated();
		http.formLogin().loginProcessingUrl("/login").permitAll();
		http.logout().logoutSuccessUrl("/logOut").clearAuthentication(true).logoutSuccessUrl("/login");
		http.csrf().disable();
		
		http.sessionManagement()
		.sessionCreationPolicy(SessionCreationPolicy.IF_REQUIRED)		//always 如果没有session存在就创建一个
																		//ifRequired 如果需要就创建一个Session（默认）登录时
																		//never  SpringSecurity 将不会创建Session，但是如果应用中其他地方创建了Session，那么Spring Security将会使用它。
																		//stateless SpringSecurity将绝对不会创建Session，也不使用Session
		 
        .invalidSessionUrl("/session/invalid.html") //当session失效后的跳转页面
        .maximumSessions(1);      //最大session数量(即同一用户，只能登录一个终端，前一天踢掉后一个)
        
		
		
		
	}
	
	 protected void configure5(HttpSecurity http) throws Exception {

//	        ValidateCodeFileter validateCodeFileter = new ValidateCodeFileter();
//	        validateCodeFileter.setAuthenticationFailureHandler(authenticationfailHandler);
//
//	        MessageCodeFileter messageCodeFileter = new MessageCodeFileter();
//	        messageCodeFileter.setAuthenticationFailureHandler(authenticationfailHandler);

	        //  addFilterBefore  设置一个前置过滤器， 第一个参数前置过滤器，第二参数在哪个过滤器之前
//	        http.addFilterBefore(validateCodeFileter, UsernamePasswordAuthenticationFilter.class)
//	            .addFilterBefore(messageCodeFileter,UsernamePasswordAuthenticationFilter.class);
//
//
//	        http.formLogin()
//	                .loginPage("/authentication/reuire")        //自定义登录页面
//	                .loginProcessingUrl("/login")           //  当用户提交登录信息时的地址
//	                .successHandler(authenticationSuccessHandler)   //当登录成功时，进入此handler
//	                .failureHandler(authenticationfailHandler);
//	        //  .defaultSuccessUrl("/seccess.html")       //注意： defaultSuccessUrl() 和 successHandler() 同时存在时，只执行successHandler
//
//	        http.logout()           //退出操作
//	                .logoutUrl("/signOut")    //退出时的url
//	               // .logoutSuccessHandler()   //退出成功时，需要做的处理，   注意：logoutSuccessHandler 与 logoutSuccessUrl 二选一
//	                .logoutSuccessUrl("/imooc-logout.html")  //退出成功时，去往的url
//	                .deleteCookies("JSESSIONID");       //退出时，删除浏览器里的cookie
//
//
//	        http.authorizeRequests()
//	                .antMatchers("/authentication/reuire","/imooc-signIn.html","/session/invalid.html","/oauth/authorize").permitAll()   //忽略要认证的url
//	                .anyRequest()
//	               .authenticated();
//
//	        http .csrf().disable();// 禁用跨站攻击;
//
//	        http.sessionManagement()
//	                .invalidSessionUrl("/session/invalid.html"); //当session失效后的跳转页面
////	                .maximumSessions(1)      //最大session数量(即同一用户，只能登录一个终端，前一天踢掉后一个)
////	                .expiredSessionStrategy(new ExpiredSessionStrategy());
//
//	        http.rememberMe()           // 记住我功能
//	                .tokenRepository(persistentTokenRepository())       //配置数据源
//	                .tokenValiditySeconds(3600)                         // 过期时间，默认是秒
//	                .userDetailsService(userDetailsService);          //  系统从数据库获取用户token，用该userDetailsService进行登录
//
//	        http.apply(smsCodeAuthenticationSecurityConfig);
	    }
	
	public static void main(String[] args) {
		
		 String encode = new BCryptPasswordEncoder().encode("123456");
		 System.out.println(encode);
		
	}

}
