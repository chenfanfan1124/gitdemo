package cn.inlee.config;

import java.util.concurrent.Executors;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.scheduling.annotation.SchedulingConfigurer;
import org.springframework.scheduling.config.ScheduledTaskRegistrar;
import org.springframework.web.client.RestTemplate;

import com.baomidou.mybatisplus.extension.plugins.PaginationInterceptor;

@Configuration
public class BeanConficg implements SchedulingConfigurer{
	
	
	public void configureTasks(ScheduledTaskRegistrar taskRegistrar) {
		
		taskRegistrar.setScheduler(Executors.newScheduledThreadPool(100));
	}
	
	
	
}
